#include <stdio.h>

int main() {
    int i;
    scanf("%d", &i);

    if (i > 0) {
        if (i % 2 == 0) {
            printf("Even Number");
        } else {
            printf("Odd Number");
        }
    } else {
        printf("Non positive");
    }

    return 0;
}
