#include <stdio.h>

int main() {
    int menu;

    printf("1. ADD\n");
    printf("2. EDIT\n");
    printf("3. DEL\n");

    scanf("%d", &menu);

    if (menu == 1) {
        printf("You selected ADD.");
    }
    else if (menu == 2) {
        printf("You selected EDIT.");
    }
    else if (menu == 3) {
        printf("You selected DEL.");
    }
    else {
        printf("Wrong choice.");
    }

    return 0;
}
