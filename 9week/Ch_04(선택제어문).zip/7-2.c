#include <stdio.h>

int main() {
    char eng;

    scanf(" %c", &eng);

    if (eng == 'A') {
        printf("Excellent");
    }
    else if (eng == 'B') {
        printf("Good");
    }
    else if (eng == 'C') {
        printf("Usually");
    }
    else {
        printf("error");
    }

    return 0;
}
