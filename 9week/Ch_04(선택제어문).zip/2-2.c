#include <stdio.h>

int main() {
    int height;
    int weight;
    int sum;
    scanf("%d" "%d", &height, &weight);
    
    sum = weight + 100 - height;
    printf("%d\n", sum);

    if (sum > 0) {
        printf("Obesity\n");
        printf("Need control\n");
    }

    return 0;

}