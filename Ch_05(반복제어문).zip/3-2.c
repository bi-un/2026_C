#include <stdio.h>

int main() {
    int i;

    while(1) {
        scanf("%d", &i);

        if (i == 0) {
            break;
        }

        if (i > 0) {
            printf("positive number\n");
        }
        else {
            printf("negative number\n");
        }
    }

    return 0;
    
}