#include <stdio.h>

int main() {
    int x = 5;

    x = x + 3;
    printf("%d\n", x);

    x = x - 1;
    printf("%d %d %d\n", x, x - 2, x + 1);

    return 0;
}