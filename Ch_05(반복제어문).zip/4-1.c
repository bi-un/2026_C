#include <stdio.h>

int main() {
    int i;
    int cnt = 0;
    int sum = 0;
    double avg = 0;

    while (1) {
        scanf("%d", &i);

        if (i == 0) {
            break;
        }

        cnt++;
        sum += i;
    }

    avg = (double)sum / cnt;

    printf("cnt = %d\n", cnt);
    printf("sum = %d\n", sum);
    printf("avg = %.2f\n", avg);

    return 0;
}
