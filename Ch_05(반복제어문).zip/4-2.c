#include <stdio.h>

int main() {
    int i;
    int small = 0;
    int large = 0;

    while (1) {
        scanf("%d", &i);

        if (i >= 100) {
            large++;
            break;
        }

        if (i < 50) {
            small++;
        }
        else {
            large++;
        }
    }

    printf("small : %d\n", small);
    printf("large : %d\n", large);

    return 0;
}